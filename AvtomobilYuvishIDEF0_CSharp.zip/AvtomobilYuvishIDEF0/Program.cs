using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace AvtomobilYuvishIDEF0;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class ProcessStep
{
    public string Id { get; }
    public string Title { get; }
    public string Input { get; }
    public string Control { get; }
    public string Output { get; }
    public string Mechanism { get; }
    public ProcessStep(string id, string title, string input, string control, string output, string mechanism)
    {
        Id = id; Title = title; Input = input; Control = control;
        Output = output; Mechanism = mechanism;
    }
    public override string ToString() => $"{Id} — {Title}";
}

internal sealed class MainForm : Form
{
    internal static readonly ProcessStep[] Steps =
    {
        new("A1", "Buyurtmani qabul qilish", "Mijoz talabi, avtomobil", "Xizmat narxlari, ish tartibi", "Qabul qilingan buyurtma", "Administrator, kompyuter"),
        new("A2", "Yuvishga tayyorlash", "Qabul qilingan buyurtma, avtomobil", "Xavfsizlik qoidalari", "Yuvishga tayyor avtomobil", "Xodim, suv, yuvish vositalari"),
        new("A3", "Yuvish va quritish", "Yuvishga tayyor avtomobil", "Tozalik va sifat standarti", "Yuvilgan, quritilgan avtomobil", "Yuvuvchi, uskuna, suv, elektr"),
        new("A4", "Tekshirish va topshirish", "Yuvilgan avtomobil", "Sifat talablari, to'lov qoidasi", "Toza avtomobil, chek", "Nazoratchi, kassir, terminal")
    };

    private readonly DiagramCanvas canvas = new() { Dock = DockStyle.Fill, BackColor = Color.White };
    private readonly Label details = new() { Dock = DockStyle.Fill, AutoSize = false, Padding = new Padding(14), Font = new Font("Segoe UI", 10.5f), ForeColor = Color.FromArgb(40, 55, 75) };
    private readonly Label status = new() { AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.FromArgb(35, 106, 83) };
    private readonly Button nextButton = MakeButton("Keyingi bosqich", Color.FromArgb(32, 101, 174));
    private readonly Button resetButton = MakeButton("Qayta boshlash", Color.FromArgb(90, 100, 115));
    private readonly Button exportButton = MakeButton("PNG eksport", Color.FromArgb(33, 133, 91));
    private readonly ComboBox modePicker = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 240, Font = new Font("Segoe UI", 11) };
    private int progressIndex = -1;

    public MainForm()
    {
        Text = "IDEF0 Process Modeler — Avtomobil yuvish xizmati";
        MinimumSize = new Size(1050, 710);
        Size = new Size(1340, 850);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(242, 246, 251);
        Font = new Font("Segoe UI", 10);

        var header = new Panel { Dock = DockStyle.Top, Height = 114, BackColor = Color.FromArgb(24, 45, 75) };
        var heading = new Label { Text = "AVTOMOBIL YUVISH XIZMATI", Font = new Font("Segoe UI", 19, FontStyle.Bold), ForeColor = Color.White, Location = new Point(24, 12), AutoSize = true };
        var subtitle = new Label { Text = "IDEF0 metodologiyasi  |  A-0 kontekst  |  A0 dekompozitsiya", Font = new Font("Segoe UI", 10), ForeColor = Color.FromArgb(202, 218, 238), Location = new Point(27, 54), AutoSize = true };
        modePicker.Items.AddRange(new object[] { "A-0 — Kontekst diagrammasi", "A0 — Dekompozitsiya" });
        modePicker.SelectedIndex = 0;
        modePicker.Location = new Point(26, 77);
        modePicker.Width = 270;
        header.Controls.AddRange(new Control[] { heading, subtitle, modePicker });

        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 56, BackColor = Color.White, Padding = new Padding(14, 9, 14, 6), WrapContents = false };
        toolbar.Controls.Add(exportButton);
        toolbar.Controls.Add(nextButton);
        toolbar.Controls.Add(resetButton);
        toolbar.Controls.Add(new Label { Text = "  Bosqichlar ustiga bosing — ma'lumotlar ko'rinadi.", AutoSize = true, Padding = new Padding(12, 8, 0, 0), ForeColor = Color.DimGray });

        var right = new Panel { Dock = DockStyle.Right, Width = 320, BackColor = Color.White, Padding = new Padding(8) };
        var detailTitle = new Label { Text = "JARAYON MA'LUMOTLARI", Dock = DockStyle.Top, Height = 48, Font = new Font("Segoe UI", 12, FontStyle.Bold), Padding = new Padding(12, 12, 0, 0) };
        var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 115, Padding = new Padding(12, 4, 12, 12) };
        status.Dock = DockStyle.Top;
        status.Height = 32;
        bottomPanel.Controls.Add(new Label { Dock = DockStyle.Fill, Text = "Simulyatsiya: 'Keyingi bosqich' tugmasi A1 → A4 xizmat jarayonini ketma-ket ko'rsatadi. Bu o'quv modeli; haqiqiy to'lovni bajarmaydi.", Font = new Font("Segoe UI", 9), ForeColor = Color.DimGray });
        bottomPanel.Controls.Add(status);
        right.Controls.Add(details);
        right.Controls.Add(bottomPanel);
        right.Controls.Add(detailTitle);

        var diagramHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(14) };
        diagramHost.Controls.Add(canvas);
        Controls.Add(diagramHost);
        Controls.Add(right);
        Controls.Add(toolbar);
        Controls.Add(header);

        modePicker.SelectedIndexChanged += (_, _) => { canvas.IsContext = modePicker.SelectedIndex == 0; ShowDetail(null); };
        exportButton.Click += (_, _) => ExportDiagram();
        nextButton.Click += (_, _) => NextStep();
        resetButton.Click += (_, _) => ResetProgress();
        canvas.StepClicked += step => ShowDetail(step);
        ShowDetail(null);
        UpdateProgress();
    }

    private static Button MakeButton(string title, Color color) => new()
    {
        Text = title, BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
        Width = 145, Height = 35, Margin = new Padding(5, 0, 5, 0), Cursor = Cursors.Hand
    };

    private void ShowDetail(ProcessStep? step)
    {
        if (step is null)
        {
            details.Text = canvas.IsContext
                ? "A-0 — Umumiy jarayon\n\nINPUT (chap):\n• Kir avtomobil\n• Mijozning buyurtmasi\n\nCONTROL (yuqori):\n• Xizmat narxlari\n• Sifat standartlari\n• Xavfsizlik qoidalari\n\nOUTPUT (o'ng):\n• Toza avtomobil\n• To'lov cheki\n\nMECHANISM (past):\n• Xodimlar\n• Yuvish uskunalari\n• Suv va vositalar"
                : "A0 — Jarayon bosqichlari\n\nA1 — Buyurtmani qabul qilish\n\nA2 — Yuvishga tayyorlash\n\nA3 — Yuvish va quritish\n\nA4 — Tekshirish va topshirish\n\nBatafsil ma'lumot olish uchun diagrammadagi blokni bosing.";
        }
        else
        {
            details.Text = $"{step.Id} — {step.Title}\n\nINPUT (kirish):\n{step.Input}\n\nCONTROL (boshqaruv):\n{step.Control}\n\nOUTPUT (chiqish):\n{step.Output}\n\nMECHANISM (mexanizm):\n{step.Mechanism}";
        }
        canvas.SelectedId = step?.Id;
        canvas.Invalidate();
    }

    private void NextStep()
    {
        if (progressIndex >= Steps.Length - 1) { MessageBox.Show("Jarayon yakunlandi: avtomobil mijozga topshirildi!", "Tayyor", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
        progressIndex++;
        modePicker.SelectedIndex = 1;
        ShowDetail(Steps[progressIndex]);
        UpdateProgress();
    }

    private void ResetProgress()
    {
        progressIndex = -1;
        ShowDetail(null);
        UpdateProgress();
    }

    private void UpdateProgress()
    {
        status.Text = progressIndex < 0 ? "Holat: xizmat boshlanmagan" : progressIndex == 3 ? "Holat: xizmat yakunlandi ✓" : $"Holat: {Steps[progressIndex].Id} bajarildi ({progressIndex + 1}/4)";
        nextButton.Enabled = progressIndex < 3;
        canvas.CompletedThrough = progressIndex;
        canvas.Invalidate();
    }

    private void ExportDiagram()
    {
        using var dialog = new SaveFileDialog
        {
            Filter = "PNG image (*.png)|*.png",
            FileName = canvas.IsContext ? "IDEF0_A-0_Avtomobil_yuvish.png" : "IDEF0_A0_Avtomobil_yuvish.png"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            using var bitmap = new Bitmap(1600, 1000);
            using var graphics = Graphics.FromImage(bitmap);
            canvas.Render(graphics, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
            bitmap.Save(dialog.FileName, ImageFormat.Png);
            MessageBox.Show("PNG muvaffaqiyatli saqlandi!", "Eksport", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show($"Saqlashda xatolik: {ex.Message}", "Xatolik", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}

internal sealed class DiagramCanvas : Control
{
    public bool IsContext { get; set; } = true;
    public string? SelectedId { get; set; }
    public int CompletedThrough { get; set; } = -1;
    public event Action<ProcessStep?>? StepClicked;

    public DiagramCanvas()
    {
        DoubleBuffered = true;
        Cursor = Cursors.Hand;
        ResizeRedraw = true;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Render(e.Graphics, ClientRectangle);
    }

    public void Render(Graphics graphics, Rectangle area)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.Clear(Color.White);
        var state = graphics.Save();
        graphics.TranslateTransform(area.Left, area.Top);
        graphics.ScaleTransform(area.Width / 1000f, area.Height / 650f);
        using var headerFont = new Font("Segoe UI", 19, FontStyle.Bold);
        using var captionFont = new Font("Segoe UI", 13, FontStyle.Bold);
        using var smallFont = new Font("Segoe UI", 10);
        using var ink = new SolidBrush(Color.FromArgb(35, 53, 77));
        graphics.DrawString(IsContext ? "A-0  |  KONTEKST DIAGRAMMASI" : "A0  |  DEKOMPOZITSIYA DIAGRAMMASI", headerFont, ink, 38, 28);
        graphics.DrawString("IDEF0: chap = Input, yuqori = Control, o'ng = Output, past = Mechanism", smallFont, Brushes.Gray, 38, 70);
        if (IsContext) DrawContext(graphics);
        else DrawDecomposition(graphics);
        graphics.Restore(state);
    }

    private static void Label(Graphics g, string text, RectangleF rectangle, float size = 12, bool bold = false)
    {
        using var font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
        using var brush = new SolidBrush(Color.FromArgb(27, 45, 67));
        using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        g.DrawString(text, font, brush, rectangle, format);
    }

    private static void Box(Graphics g, RectangleF rect, string title, string id, bool highlighted = false, bool completed = false)
    {
        using var fill = new SolidBrush(completed ? Color.FromArgb(223, 247, 233) : highlighted ? Color.FromArgb(213, 230, 252) : Color.FromArgb(237, 245, 254));
        using var pen = new Pen(highlighted ? Color.FromArgb(31, 98, 178) : Color.FromArgb(58, 89, 126), highlighted ? 4 : 2);
        g.FillRectangle(fill, rect);
        g.DrawRectangle(pen, rect.X, rect.Y, rect.Width, rect.Height);
        Label(g, title, new RectangleF(rect.X + 7, rect.Y + 4, rect.Width - 14, rect.Height - 32), 12, true);
        Label(g, id, new RectangleF(rect.Right - 46, rect.Bottom - 28, 38, 25), 11, true);
    }

    private static void Arrow(Graphics g, PointF from, PointF to, string? label = null, PointF? labelAt = null)
    {
        using var pen = new Pen(Color.FromArgb(67, 91, 117), 2.5f) { CustomEndCap = new AdjustableArrowCap(5, 6) };
        g.DrawLine(pen, from, to);
        if (label is not null && labelAt.HasValue)
            Label(g, label, new RectangleF(labelAt.Value.X, labelAt.Value.Y, 220, 55), 11);
    }

    private void DrawContext(Graphics g)
    {
        Box(g, new RectangleF(344, 255, 350, 180), "Avtomobil yuvish\nxizmatini amalga oshirish", "A-0", SelectedId == "A-0");
        Arrow(g, new PointF(54, 341), new PointF(344, 341), "Kir avtomobil\nMijoz buyurtmasi", new PointF(90, 276));
        Arrow(g, new PointF(519, 151), new PointF(519, 255), "Narxlar, sifat standartlari,\nxavfsizlik qoidalari", new PointF(535, 165));
        Arrow(g, new PointF(694, 341), new PointF(953, 341), "Toza avtomobil\nTo'lov cheki", new PointF(714, 276));
        Arrow(g, new PointF(519, 555), new PointF(519, 435), "Xodimlar, uskunalar,\nsuv va yuvish vositalari", new PointF(535, 480));
    }

    private void DrawDecomposition(Graphics g)
    {
        float[] xs = { 48, 285, 522, 759 };
        string[] titles = { "Buyurtmani\nqabul qilish", "Yuvishga\ntayyorlash", "Yuvish va\nquritish", "Tekshirish\nva topshirish" };
        for (int i = 0; i < 4; i++)
        {
            var r = new RectangleF(xs[i], 293, 193, 114);
            Box(g, r, titles[i], $"A{i + 1}", SelectedId == $"A{i + 1}", i <= CompletedThrough);
            if (i < 3) Arrow(g, new PointF(r.Right, 350), new PointF(xs[i + 1], 350));
            Arrow(g, new PointF(xs[i] + 95, 214), new PointF(xs[i] + 95, 293));
            Arrow(g, new PointF(xs[i] + 95, 488), new PointF(xs[i] + 95, 407));
        }
        Label(g, "Narxlar va\nish tartibi", new RectangleF(37, 145, 220, 65), 10);
        Label(g, "Xavfsizlik\nqoidalari", new RectangleF(272, 145, 220, 65), 10);
        Label(g, "Sifat\nstandartlari", new RectangleF(510, 145, 220, 65), 10);
        Label(g, "Sifat va to'lov\nqoidalari", new RectangleF(747, 145, 220, 65), 10);
        Label(g, "Administrator", new RectangleF(37, 490, 220, 60), 10);
        Label(g, "Xodim, vositalar", new RectangleF(272, 490, 220, 60), 10);
        Label(g, "Yuvuvchi, uskuna", new RectangleF(510, 490, 220, 60), 10);
        Label(g, "Nazoratchi, kassir", new RectangleF(747, 490, 220, 60), 10);
        Arrow(g, new PointF(9, 350), new PointF(48, 350));
        Arrow(g, new PointF(952, 350), new PointF(990, 350));
        Label(g, "Avtomobil + buyurtma", new RectangleF(9, 243, 225, 42), 10);
        Label(g, "Toza avtomobil + chek", new RectangleF(760, 243, 230, 42), 10);
        Label(g, "A1 → A2 → A3 → A4: xizmatni bajarish ketma-ketligi", new RectangleF(170, 585, 660, 40), 12, true);
    }

    protected override void OnMouseClick(MouseEventArgs e)
    {
        base.OnMouseClick(e);
        if (IsContext) { SelectedId = "A-0"; StepClicked?.Invoke(null); return; }
        float x = e.X * 1000f / Math.Max(1, ClientSize.Width);
        float y = e.Y * 650f / Math.Max(1, ClientSize.Height);
        float[] xs = { 48, 285, 522, 759 };
        for (var i = 0; i < 4; i++)
            if (new RectangleF(xs[i], 293, 193, 114).Contains(x, y))
            {
                StepClicked?.Invoke(MainForm.Steps[i]);
                return;
            }
    }
}
