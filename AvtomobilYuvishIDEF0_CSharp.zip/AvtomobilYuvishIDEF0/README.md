# Avtomobil yuvish xizmati — IDEF0 (C# Windows Forms)

IDEF0 metodologiyasi uchun **ishlaydigan interaktiv o'quv dasturi**.

## Talablar
- Windows 10 yoki Windows 11
- **.NET 8 SDK**: https://dotnet.microsoft.com/download/dotnet/8.0
- Visual Studio 2022/2026 (ixtiyoriy; .NET SDK bilan ham ishga tushadi)

## Ishga tushirish
1. ZIP arxivni oching.
2. `AvtomobilYuvishIDEF0.csproj` faylini Visual Studio'da oching va **F5** bosing.
3. Yoki loyiha papkasida terminal oching:

```powershell
dotnet run --project AvtomobilYuvishIDEF0.csproj
```

## EXE yaratish (Windows x64, .NET o'rnatilishi talab qilinmaydigan variant)

```powershell
dotnet publish AvtomobilYuvishIDEF0.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
```

Natija: `publish/AvtomobilYuvishIDEF0.exe`. Publish birinchi safar NuGet va .NET runtime yuklash uchun internet talab qilishi mumkin.

## Dastur imkoniyatlari
- A-0: kontekst diagrammasi
- A0: 4 bosqichli dekompozitsiya
- IDEF0 ICOM (Input, Control, Output, Mechanism) ma'lumotlari
- A1–A4 bloklarini bosib tavsifni ko'rish
- Jarayonni ketma-ket simulyatsiya qilish
- Joriy diagrammani PNG rasmga eksport qilish

> Eslatma: Bu dastur Process Modeler dasturining o'zi emas va uning maxsus loyiha formatiga eksport qilmaydi. Bu mustaqil C# Windows Forms ilovasi; universitet topshirig'ida Process Modeler ichida chizish talab qilinsa, diagrammani o'sha dasturda ham yaratish zarur.
